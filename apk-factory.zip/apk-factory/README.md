# 📱 APK Factory

Fábrica automática de APK para Android, 100 % dentro de GitHub (gratis).

1. Abrís una página en tu teléfono.
2. Subís tu **HTML**, tu **ZIP** o la **dirección de tu web**.
3. Tocás **Crear APK**.
4. GitHub construye y firma el APK y **te manda un correo** con el enlace de descarga.
5. Si algo no te gusta o falla, lo **escribís en una casilla** y la IA lo repara o lo cambia; tocás **Aplicar y crear de nuevo**.

> No necesitás instalar Android Studio: GitHub usa las mismas herramientas (Android SDK + Gradle) en sus servidores.
> Igual, cada vez se guarda el **proyecto Android completo** como descarga (artefacto de la ejecución) por si querés abrirlo en Android Studio.

---

## Instalación (una sola vez, ~10 minutos)

### Paso 1 · Crear el repositorio
1. Entrá a <https://github.com> → **New repository**.
2. Nombre: `apk-factory`. Marcá **Public** (así GitHub Pages es gratis y las ejecuciones no gastan minutos) y **Add a README file**.

> ⚠️ En un repositorio público, tu HTML/ZIP y los APK son visibles para cualquiera que conozca el enlace. Si tu app tiene datos privados, usá un repositorio privado (ver «Privacidad» abajo).

### Paso 2 · Crear un token de acceso
GitHub → tu foto → **Settings** → **Developer settings** → **Personal access tokens** → **Fine-grained tokens** → **Generate new token**.
- **Expiration:** 90 días (o lo que prefieras).
- **Repository access:** *Only select repositories* → `apk-factory`.
- **Permissions (Repository):** `Contents` = Read and write · `Actions` = Read and write · `Workflows` = Read and write · `Pages` = Read and write · `Metadata` = Read.
- Copiá el token (empieza con `github_pat_`). **No lo compartas con nadie.**

### Paso 3 · Instalar los archivos (automático)
Abrí el archivo **`instalador.html`** en el navegador del teléfono o la computadora, pegá tu `usuario/apk-factory` y el token, y tocá **Instalar**. Sube todos los archivos y activa GitHub Pages.

*(Alternativa a mano: subí el contenido de esta carpeta al repositorio, respetando las carpetas `.github/workflows`, `scripts`, `docs` y `jobs`. Luego en **Settings → Pages** elegí «Deploy from a branch», rama `main`, carpeta `/docs`.)*

### Paso 4 · Cargar los «secretos»
En el repositorio: **Settings → Secrets and variables → Actions → New repository secret**.

| Secreto | Para qué | Cómo conseguirlo |
|---|---|---|
| `MAIL_USERNAME` | Tu Gmail que envía el aviso | Ej.: `arayagustavocesar22@gmail.com` |
| `MAIL_PASSWORD` | Permiso para enviar | Cuenta de Google → Seguridad → activar verificación en 2 pasos → <https://myaccount.google.com/apppasswords> → crear «contraseña de aplicación» (16 letras, sin espacios) |
| `SIGNING_PASSWORD` | Firma de tus APK | Inventá una contraseña larga y guardala. Con ella las versiones nuevas se instalan **encima** de las anteriores sin desinstalar. **No la cambies después.** |
| `ANTHROPIC_API_KEY` | La IA que aplica tus cambios y repara errores | Opcional. Cuenta en <https://console.anthropic.com> → API keys. Tiene costo por uso (centavos por pedido). Sin esta clave todo funciona, salvo la casilla de cambios. |

### Paso 5 · Usar
Abrí `https://TUUSUARIO.github.io/apk-factory/`, entrá en **⚙️ Conexión con GitHub**, pegá tu repositorio y el token, **Guardar y probar**. ¡Listo!

---

## Cómo se usa

**App nueva:** elegí HTML / ZIP / URL, nombre, color, orientación e icono (opcional) → **🚀 Crear APK**. Tarda entre 4 y 10 minutos (la primera vez, un poco más). Podés cerrar la página: te llega el correo.

**Cambios o reparaciones:** en la tarjeta de tu app escribí, por ejemplo:
- «No me gusta el color, ponelo azul»
- «Cambiá el botón Guardar por Enviar y hacelo más grande»
- «Al tocar Calcular no pasa nada»
- «No se instala, dice *app no instalada*»

Tocá **🛠 Aplicar y crear de nuevo**. La IA modifica el código, se genera un APK nuevo y te llega otro correo. Los cambios **se acumulan**: el siguiente pedido parte de la versión ya modificada.

**Subir versión nueva:** reemplaza tu HTML/ZIP por uno actualizado (descarta las modificaciones de la IA anteriores).

### Mejoras incluidas
- Funciona **sin conexión**: las librerías JavaScript de internet (CDN) se guardan dentro de la app.
- Agrega la etiqueta *viewport* si falta (se ve bien en el teléfono).
- **Avisos automáticos** de cosas que pueden fallar (fuentes de internet, `localhost`, etc.).
- **Diagnóstico en español** cuando algo falla, también por correo.
- Firma persistente (clave cifrada guardada en `keystore/`) → actualizaciones encima de la versión instalada.
- Icono propio o generado con iniciales + color; orientación vertical/horizontal.
- Historial de versiones, botón compartir y copiar enlace, vista previa del HTML antes de crear.
- Descarga del proyecto Android completo para Android Studio.

---

## Instalar el APK en el teléfono
1. Abrí el correo (o la página) **desde el teléfono** y tocá **Descargar APK**.
2. Abrí el archivo descargado. Si Android lo pide, permití **«Instalar apps de esta fuente»** (Ajustes → Seguridad).
3. Android 6.0 o superior.

Si dice «app no instalada»: desinstalá la versión anterior de la misma app (si se firmó con otra clave), liberá espacio, y probá de nuevo. También podés escribir el error en la casilla y la IA te guía.

## Privacidad y límites
- **Repo privado:** los enlaces de descarga del correo exigen iniciar sesión en GitHub, y GitHub Pages privado requiere plan de pago. Alternativa: abrir `docs/index.html` desde un archivo local (funciona igual, solo necesita internet).
- **Minutos gratis:** en repos públicos no hay límite; en privados, 2 000 min/mes (≈ 200 apps).
- **Gmail no permite adjuntar .apk**, por eso el correo trae un enlace.
- Esto genera APK para **instalación directa**. Para publicar en Google Play se necesita un paquete AAB y tu propia clave: se puede agregar.
- Solo funciona con apps web (HTML/CSS/JS). Funciones nativas (cámara, notificaciones push, etc.) requieren plugins adicionales.
- Las cuentas de correo y claves se guardan solo como «secretos» de GitHub; nunca en el código.

## Estructura
```
.github/workflows/build-apk.yml   ← el flujo automático
scripts/                          ← preparar, IA, parchear Android, firmar, correo
docs/index.html                   ← la interfaz (GitHub Pages)
jobs/<app>/                       ← tus apps (origen, resultado, historial)
keystore/signing.jks.enc          ← clave de firma cifrada (se crea sola)
```
