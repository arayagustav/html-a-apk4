#!/usr/bin/env bash
# Orquesta todas las etapas. Nunca sale con error: deja el resultado en build/status
# para que SIEMPRE se guarde el informe y se envíe el correo (éxito o fallo).
set -uo pipefail

mkdir -p build/out
echo failure > build/status
rm -f build/failed_stage build/edited.flag

# Las etapas que ejecutan código de terceros (npm, Gradle) no ven ninguna clave secreta.
CLEAN=(env -u ANTHROPIC_API_KEY -u MAIL_USERNAME -u MAIL_PASSWORD -u SIGNING_PASSWORD -u GH_TOKEN)

fail() {
  echo "::error::Falló la etapa: $1"
  echo "$1" > build/failed_stage
  exit 0
}

# --- validar -------------------------------------------------------------
[[ "${JOB_ID:-}" =~ ^[a-z0-9-]{1,40}$ ]] || fail validar
JOB="jobs/$JOB_ID"
[ -f "$JOB/meta.json" ] || { echo "Falta $JOB/meta.json"; fail validar; }

echo "=== Datos de la app ==="
python3 scripts/job_info.py "$JOB" || fail validar
# shellcheck disable=SC1091
set -a; source build/job.env; set +a

echo "=== Instalando Pillow (iconos) ==="
python3 -m pip install --quiet pillow || fail preparar

echo "=== Preparando tus archivos ==="
python3 scripts/prepare_app.py "$JOB" build/proj || fail preparar

if [ -n "${NOTES:-}" ]; then
  echo "=== Aplicando tus cambios con IA ==="
  python3 scripts/ai_edit.py "$JOB" build/proj/www "$NOTES" || fail ia
fi

echo "=== Creando el proyecto ==="
python3 scripts/make_project.py "$JOB" build/proj || fail proyecto

echo "=== Instalando Capacitor ==="
( cd build/proj && "${CLEAN[@]}" npm install --no-audit --no-fund ) || fail npm

echo "=== Generando la carpeta Android ==="
( cd build/proj && "${CLEAN[@]}" npx cap add android && "${CLEAN[@]}" npx cap sync android ) || fail android

echo "=== Ajustando nombre, icono y versión ==="
python3 scripts/patch_android.py "$JOB" build/proj "${GITHUB_RUN_NUMBER:-1}" "1.${VERSION_N}" || fail ajustes

echo "=== Compilando con Gradle (tarda unos minutos) ==="
( cd build/proj/android && chmod +x gradlew && "${CLEAN[@]}" ./gradlew assembleRelease --no-daemon --console=plain ) || fail gradle

echo "=== Firmando el APK ==="
bash scripts/sign_apk.sh || fail firma

echo success > build/status
echo "=== Listo: build/out/$APK_NAME ==="
