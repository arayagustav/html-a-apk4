#!/usr/bin/env python3
"""Prepara la carpeta web (www) a partir del HTML, ZIP o URL de la persona.

Mejoras automáticas:
- Descarga las librerías JavaScript de internet (CDN) y las guarda dentro de la app,
  para que funcione sin conexión.
- Agrega la etiqueta viewport si falta (para que se vea bien en el teléfono).
- Genera una lista de avisos (warnings) con cosas que pueden fallar.
"""
import hashlib
import os
import re
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path
from urllib.parse import urlparse

sys.path.insert(0, os.path.dirname(__file__))
from common import effective_config, write_json  # noqa: E402

MAX_ZIP_BYTES = 300 * 1024 * 1024
MAX_VENDOR_BYTES = 8 * 1024 * 1024
UA = {"User-Agent": "Mozilla/5.0 (APK-Factory)"}

SCRIPT_RE = re.compile(
    r"<script\b([^>]*?)\bsrc\s*=\s*([\"'])(https://[^\"']+)\2([^>]*)>", re.I
)
INTEGRITY_RE = re.compile(r"\sintegrity\s*=\s*(?:\"[^\"]*\"|'[^']*')", re.I)
CROSSORIGIN_RE = re.compile(
    r"\scrossorigin(?:\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s>]+))?", re.I
)


def safe_extract(zip_path, dest):
    dest = Path(dest).resolve()
    dest.mkdir(parents=True, exist_ok=True)
    total = 0
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            total += info.file_size
            if total > MAX_ZIP_BYTES:
                raise SystemExit("El ZIP descomprimido supera 300 MB.")
            target = (dest / info.filename).resolve()
            if target != dest and dest not in target.parents:
                raise SystemExit("El ZIP contiene rutas inseguras.")
        z.extractall(dest)


def find_web_root(folder):
    folder = Path(folder)
    shutil.rmtree(folder / "__MACOSX", ignore_errors=True)
    candidates = sorted(
        folder.rglob("index.html"), key=lambda p: len(p.relative_to(folder).parts)
    )
    if candidates:
        return candidates[0].parent
    htmls = [p for p in folder.rglob("*.html") if "__MACOSX" not in p.parts]
    if len(htmls) == 1:
        shutil.copy(htmls[0], htmls[0].parent / "index.html")
        return htmls[0].parent
    raise SystemExit("No encontré un archivo index.html dentro del ZIP.")


def fetch_vendor(url, www, cache):
    if url in cache:
        return cache[url]
    result = None
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = resp.read(MAX_VENDOR_BYTES + 1)
        if 0 < len(data) <= MAX_VENDOR_BYTES:
            ext = os.path.splitext(urlparse(url).path)[1].lower()
            if ext not in (".js", ".mjs"):
                ext = ".js"
            name = hashlib.sha1(url.encode()).hexdigest()[:12] + ext
            vendor = www / "vendor"
            vendor.mkdir(exist_ok=True)
            (vendor / name).write_bytes(data)
            result = vendor / name
    except Exception as exc:  # noqa: BLE001 - no queremos romper el build por esto
        print(f"  (no pude descargar {url}: {exc})")
    cache[url] = result
    return result


def vendorize(html_path, www, cache):
    text = html_path.read_text(encoding="utf-8", errors="ignore")
    count = 0

    def repl(m):
        nonlocal count
        local = fetch_vendor(m.group(3), www, cache)
        if not local:
            return m.group(0)
        count += 1
        before = CROSSORIGIN_RE.sub("", INTEGRITY_RE.sub("", m.group(1)))
        after = CROSSORIGIN_RE.sub("", INTEGRITY_RE.sub("", m.group(4)))
        rel = os.path.relpath(local, html_path.parent).replace(os.sep, "/")
        return f'<script{before.rstrip()} src="{rel}"{after.rstrip()}>'

    new_text = SCRIPT_RE.sub(repl, text)
    if count:
        html_path.write_text(new_text, encoding="utf-8")
    return count


def ensure_viewport(html_path):
    text = html_path.read_text(encoding="utf-8", errors="ignore")
    if re.search(r"name\s*=\s*[\"']viewport[\"']", text, re.I):
        return False
    tag = '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
    if re.search(r"<head[^>]*>", text, re.I):
        text = re.sub(r"(<head[^>]*>)", r"\1\n" + tag, text, count=1, flags=re.I)
    else:
        text = tag + "\n" + text
    html_path.write_text(text, encoding="utf-8")
    return True


def lint(www):
    warns = []
    seen = set()

    def add(msg):
        if msg not in seen:
            seen.add(msg)
            warns.append(msg)

    for h in www.rglob("*.html"):
        if "vendor" in h.relative_to(www).parts:
            continue
        t = h.read_text(encoding="utf-8", errors="ignore")
        for link in re.findall(r"<link\b[^>]*>", t, re.I):
            if re.search(r"stylesheet", link, re.I) and re.search(r"https?://", link, re.I):
                add("Usa estilos o fuentes de internet (por ejemplo Google Fonts): "
                    "sin conexión se verán distintos.")
        if re.search(r"serviceWorker\s*\.\s*register", t):
            add("Registra un service worker: no hace falta dentro de la app y puede dar problemas.")
        if re.search(r"https?://(localhost|127\.0\.0\.1)", t):
            add("Llama a un servidor 'localhost': en el teléfono ese servidor no existe.")
        if re.search(r"<script[^>]+src\s*=\s*[\"']http://", t, re.I):
            add("Carga scripts por http (no seguro); Android puede bloquearlos.")
    return warns


def main():
    job = Path(sys.argv[1])
    proj = Path(sys.argv[2])
    www = proj / "www"
    cfg = effective_config(job)
    typ = cfg.get("type")

    proj.mkdir(parents=True, exist_ok=True)
    if www.exists():
        shutil.rmtree(www)
    www.mkdir()

    current = job / "current"
    rev_file = current / ".rev"
    reuse_current = (
        current.is_dir()
        and rev_file.is_file()
        and rev_file.read_text(encoding="utf-8").strip() == str(cfg.get("source_rev"))
    )

    if reuse_current:
        print("Usando la última versión modificada (con tus cambios anteriores).")
        shutil.copytree(current, www, dirs_exist_ok=True)
        (www / ".rev").unlink(missing_ok=True)
    elif typ == "html":
        src = job / "source.html"
        if not src.is_file():
            raise SystemExit("Falta source.html")
        shutil.copy(src, www / "index.html")
    elif typ == "zip":
        src = job / "source.zip"
        if not src.is_file():
            raise SystemExit("Falta source.zip")
        tmp = proj / "_zip"
        if tmp.exists():
            shutil.rmtree(tmp)
        try:
            safe_extract(src, tmp)
        except zipfile.BadZipFile:
            raise SystemExit("El archivo ZIP está dañado o no es un ZIP válido.")
        root = find_web_root(tmp)
        shutil.copytree(root, www, dirs_exist_ok=True)
        shutil.rmtree(tmp, ignore_errors=True)
    elif typ == "url":
        url = str(cfg.get("url", ""))
        if not re.match(r"^https?://", url):
            raise SystemExit("La dirección web debe empezar con http:// o https://")
        (www / "index.html").write_text(
            '<!doctype html><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            "<body style=\"font-family:sans-serif;text-align:center;padding:48px\">"
            "<h2>Sin conexión</h2><p>Esta app necesita internet.</p>"
            '<button onclick="location.reload()" style="padding:12px 24px">Reintentar</button>',
            encoding="utf-8",
        )
    else:
        raise SystemExit("Tipo de origen desconocido.")

    if not (www / "index.html").is_file():
        raise SystemExit("No encontré index.html en la app.")

    warnings = []
    if typ != "url":
        cache = {}
        vendored = 0
        for html in list(www.rglob("*.html")):
            if "vendor" in html.relative_to(www).parts:
                continue
            vendored += vendorize(html, www, cache)
            ensure_viewport(html)
        if vendored:
            print(f"Librerías de internet guardadas dentro de la app: {vendored}")
        warnings = lint(www)

    write_json("build/warnings.json", warnings)
    files = sum(1 for p in www.rglob("*") if p.is_file())
    print(f"Carpeta web lista: {files} archivos.")


if __name__ == "__main__":
    main()
