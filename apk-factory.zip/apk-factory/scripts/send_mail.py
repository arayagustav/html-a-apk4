#!/usr/bin/env python3
"""Envía el aviso por correo (Gmail SMTP). Nunca hace fallar el flujo.

Secretos: MAIL_USERNAME (tu Gmail) y MAIL_PASSWORD (contraseña de aplicación de Google).
Nota: Gmail bloquea adjuntos .apk, por eso el correo lleva el enlace de descarga.
"""
import html
import os
import smtplib
import ssl
import sys
from email.message import EmailMessage
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))
from common import EMAIL_RE, effective_config, read_json  # noqa: E402


def main():
    job = Path(sys.argv[1])
    to = os.environ.get("MAIL_TO", "").strip()
    user = os.environ.get("MAIL_USERNAME", "").strip()
    pwd = os.environ.get("MAIL_PASSWORD", "").strip()
    if not (job / "meta.json").is_file():
        return
    if not EMAIL_RE.match(to):
        print("Sin correo de destino válido: no se envía aviso.")
        return
    if not (user and pwd):
        print("Faltan los secretos MAIL_USERNAME / MAIL_PASSWORD: no se envía aviso por correo.")
        return

    cfg = effective_config(job)
    r = read_json(job / "result.json")
    ok = r.get("status") == "success"
    name = cfg["name"]
    lines, parts = [], []

    def add(text, tag="p", style=""):
        lines.append(text)
        parts.append(f"<{tag} style=\"{style}\">{html.escape(text)}</{tag}>")

    if ok:
        subject = f"✅ Tu app {name} está lista (v{r.get('version')})"
        add(f"Tu app «{name}» versión {r.get('version')} ya está lista para instalar.")
        link = r.get("apk_url", "")
        lines.append(f"Descargar APK: {link}")
        parts.append(
            f'<p><a href="{html.escape(link)}" style="background:#0fbf6b;color:#fff;padding:12px 20px;'
            'border-radius:8px;text-decoration:none;font-weight:bold">Descargar APK</a></p>'
        )
        add("Cómo instalar: abrí este correo desde tu teléfono Android, tocá el botón, descargá el archivo y "
            "ábrilo. Si Android lo pide, permití «instalar apps de esta fuente».")
        if r.get("ai_answer"):
            add("Sobre tus cambios: " + r["ai_answer"])
        if r.get("ai_error"):
            add("⚠ " + r["ai_error"])
        for w in r.get("warnings", []):
            add("⚠ " + w)
    else:
        subject = f"❌ No se pudo crear {name}"
        add(f"La creación de «{name}» falló.")
        diag = r.get("diagnosis", {})
        for hint in diag.get("hints", []):
            add("• " + hint)
        if diag.get("ai"):
            add("Explicación de la IA: " + diag["ai"])
        add("Podés escribir el problema en la casilla de cambios de la interfaz y apretar Crear para repararlo.")
    if r.get("run_url"):
        lines.append(f"Registro técnico: {r['run_url']}")
        parts.append(
            f'<p style="color:#666;font-size:12px">Registro técnico: <a href="{html.escape(r["run_url"])}">'
            f'{html.escape(r["run_url"])}</a></p>'
        )

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = to
    msg.set_content("\n\n".join(lines))
    msg.add_alternative(
        '<div style="font-family:Arial,sans-serif;max-width:560px;line-height:1.5">' + "".join(parts) + "</div>",
        subtype="html",
    )
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=ssl.create_default_context(), timeout=30) as s:
            s.login(user, pwd)
            s.send_message(msg)
        print("Correo enviado a", to)
    except Exception as exc:  # noqa: BLE001
        print("No se pudo enviar el correo:", exc)


if __name__ == "__main__":
    main()
